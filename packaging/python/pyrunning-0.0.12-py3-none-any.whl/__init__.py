# IMPORTS
from .pyrunning import * # since this package (running) contains a single module (pyrunning.py), flatten the module so that users can access items within the module pyrunning.py by using just the package name (pyrunning.<entity>) instead of having to add the module name too (pyrunning.pyrunning.<entity>)
