
# Running - Fenix Library - RebornOS Team

*Documentation by @shivanandvp (shivanandvp@rebornos.org)*  

*Please refer to [`LICENSE`](./LICENSE) for license information.*

## Overview

The **running** package contains the tools required to run and live-log *OS commands*, *functions*, *scripts*, and *batch jobs* either immedietly, or queued for later execution.

**Warning**: This package is still in the Alpha stage. It is not ready for production use. Please do not use for any critical software

## [PLEASE CLICK HERE](https://rebornos-team.gitlab.io/fenix/libraries/running/index.html) for the full documentation